# OpenSSH

Ansible role to install and configure OpenSSH server.
