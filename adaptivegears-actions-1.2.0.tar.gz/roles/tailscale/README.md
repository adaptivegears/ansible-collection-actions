# `andreygubarev.actions.tailscale`

## Overview

This action sets up a Tailscale client on the target instance.
