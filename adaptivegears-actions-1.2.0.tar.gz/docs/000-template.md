# EP-001: Metadata

## Summary

## Motivation

### Goals

### Non-Goals

## Proposal

## Drawbacks

## References
